AutoIt program to run Stata commands from an external text editor
Version: 5.1 (for Stata 15 and 14, with Unicode support)
Date: 28 June 2017
Author: Friedrich Huebler, fhuebler@gmail.com, www.huebler.info
Installation instructions: http://huebler.blogspot.com/2008/04/stata.html

# Sook Kim, edited Jul 2020.